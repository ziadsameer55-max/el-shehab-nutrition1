<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        // Treat requests from "localhost" as coming from the Next.js frontend (Sanctum stateful mode).
        config(['sanctum.stateful' => ['localhost']]);
    }

    /** Make the next request look like a browser request from the SPA origin. */
    protected function spa(?string $acceptLanguage = null): static
    {
        $headers = [
            'Origin' => 'http://localhost',
            'Referer' => 'http://localhost/',
            'Accept' => 'application/json',
        ];

        if ($acceptLanguage !== null) {
            $headers['Accept-Language'] = $acceptLanguage;
        }

        return $this->withHeaders($headers);
    }
}
