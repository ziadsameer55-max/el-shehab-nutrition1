<?php

namespace Tests\Feature\Auth;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SessionTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_gets_401_json_from_me(): void
    {
        $this->spa()->getJson('/api/auth/me')
            ->assertUnauthorized()
            ->assertJsonStructure(['message']);
    }

    public function test_me_returns_the_signed_in_user_without_secrets(): void
    {
        $user = User::factory()->withProfile()->create();

        $this->actingAs($user, 'web')->spa()->getJson('/api/auth/me')
            ->assertOk()
            ->assertJsonPath('id', $user->id)
            ->assertJsonMissingPath('password')
            ->assertJsonMissingPath('remember_token')
            ->assertJsonMissingPath('is_active');
    }

    public function test_logout_ends_the_session(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user, 'web')->spa()->postJson('/api/auth/logout')->assertNoContent();

        $this->assertGuest('web');
    }

    public function test_logout_requires_authentication(): void
    {
        $this->spa()->postJson('/api/auth/logout')->assertUnauthorized();
    }

    public function test_user_can_change_their_saved_language(): void
    {
        $user = User::factory()->withProfile()->create(['locale' => 'ar']);

        $this->actingAs($user, 'web')->spa()->patchJson('/api/auth/locale', ['locale' => 'en'])
            ->assertOk()
            ->assertJsonPath('locale', 'en');

        $this->assertSame('en', $user->fresh()->locale);

        $this->actingAs($user, 'web')->spa()->patchJson('/api/auth/locale', ['locale' => 'fr'])
            ->assertUnprocessable();
    }

    public function test_api_responses_are_never_cacheable(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user, 'web')->spa()->getJson('/api/auth/me');

        $this->assertStringContainsString('no-store', $response->headers->get('Cache-Control'));
        $this->assertSame('nosniff', $response->headers->get('X-Content-Type-Options'));
    }
}
