<?php

namespace Tests\Feature\Auth;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class RegisterTest extends TestCase
{
    use RefreshDatabase;

    private function payload(array $overrides = []): array
    {
        return array_merge([
            'name' => 'Test Patient',
            'email' => 'patient@example.com',
            'phone' => '+201001234567',
            'password' => 'Secret12345',
            'password_confirmation' => 'Secret12345',
            'locale' => 'en',
            'accepted_privacy' => true,
        ], $overrides);
    }

    public function test_patient_can_register_and_is_signed_in(): void
    {
        $response = $this->spa()->postJson('/api/auth/register', $this->payload());

        $response->assertCreated()
            ->assertJsonPath('email', 'patient@example.com')
            ->assertJsonPath('role', 'patient')
            ->assertJsonPath('health_profile_completed', false)
            ->assertJsonMissingPath('password');

        $this->assertAuthenticated('web');
        $this->assertDatabaseHas('patient_profiles', ['user_id' => $response->json('id')]);
        $this->assertNotNull(User::first()->patientProfile->privacy_accepted_at);
    }

    public function test_patient_is_linked_to_the_doctor(): void
    {
        $doctor = User::factory()->doctor()->create();

        $this->spa()->postJson('/api/auth/register', $this->payload())->assertCreated();

        $this->assertSame($doctor->id, User::where('email', 'patient@example.com')->first()->patientProfile->primary_doctor_id);
    }

    public function test_role_cannot_be_chosen_by_the_client(): void
    {
        $this->spa()->postJson('/api/auth/register', $this->payload(['role' => 'doctor', 'is_active' => false]))
            ->assertCreated()
            ->assertJsonPath('role', 'patient');

        $this->assertTrue(User::first()->is_active);
    }

    public function test_duplicate_email_is_rejected_case_insensitively(): void
    {
        User::factory()->create(['email' => 'patient@example.com']);

        $this->spa()->postJson('/api/auth/register', $this->payload(['email' => 'PATIENT@Example.com']))
            ->assertUnprocessable()
            ->assertJsonValidationErrors('email');
    }

    public function test_privacy_acceptance_is_required(): void
    {
        $this->spa()->postJson('/api/auth/register', $this->payload(['accepted_privacy' => false]))
            ->assertUnprocessable()
            ->assertJsonValidationErrors('accepted_privacy');

        $this->assertDatabaseCount('users', 0);
    }

    public function test_weak_or_unconfirmed_passwords_are_rejected(): void
    {
        $this->spa()->postJson('/api/auth/register', $this->payload(['password' => 'short1', 'password_confirmation' => 'short1']))
            ->assertJsonValidationErrors('password');

        $this->spa()->postJson('/api/auth/register', $this->payload(['password' => 'NoDigitsHereAtAll', 'password_confirmation' => 'NoDigitsHereAtAll']))
            ->assertJsonValidationErrors('password');

        $this->spa()->postJson('/api/auth/register', $this->payload(['password_confirmation' => 'Different12345']))
            ->assertJsonValidationErrors('password');
    }

    public function test_arabic_indic_phone_digits_are_normalized(): void
    {
        $this->spa()->postJson('/api/auth/register', $this->payload(['phone' => '٠١٠ ٠١٢٣-٤٥٦٧']))
            ->assertCreated()
            ->assertJsonPath('phone', '01001234567');
    }

    public function test_validation_messages_follow_the_request_language(): void
    {
        $this->spa('ar')->postJson('/api/auth/register', $this->payload(['accepted_privacy' => false]))
            ->assertJsonPath('errors.accepted_privacy.0', 'يجب الموافقة على سياسة الخصوصية.');

        $this->spa('en')->postJson('/api/auth/register', $this->payload(['accepted_privacy' => false]))
            ->assertJsonPath('errors.accepted_privacy.0', 'You must accept the privacy policy.');
    }

    public function test_registration_is_audited(): void
    {
        $this->spa()->postJson('/api/auth/register', $this->payload())->assertCreated();

        $this->assertTrue(DB::table('audit_logs')->where('event', 'user.registered')->exists());
    }
}
