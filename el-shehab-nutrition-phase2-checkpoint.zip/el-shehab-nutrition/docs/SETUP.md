# Local setup and verification guide

EL SHEHAB NUTRITION: Developed & Powered by CODING Systems.

Follow the steps in order. Every command is run from the folder shown. The actual results of running these steps are recorded in [`VERIFICATION.md`](VERIFICATION.md).

## Windows: the easy way (two double-clicks)

1. Install once: **PHP 8.2+** (windows.php.net), **Composer** (getcomposer.org), **Node.js 20+** (nodejs.org) and **PostgreSQL 16** (postgresql.org/download/windows; remember the password you choose for the `postgres` user).
2. Extract the ZIP, open the folder that contains `backend`, `frontend` and `docs`.
3. Double-click **`SETUP-WINDOWS.bat`**. It checks the programs and PHP extensions, creates the `el_shehab` database and its extensions, installs Composer and npm packages, writes `backend/.env` and `frontend/.env.local`, runs the migrations and creates the doctor account. At the end it prints the doctor login (email and a generated password); write it down, it is not stored.
4. Double-click **`START-WINDOWS.bat`**. It opens the backend and the website in two windows and then `http://localhost:3000` in the browser.

Status: these two scripts have **not been executed yet** (no Windows machine was available when they were written). If a step fails they print `STOP:` with the reason; send that text so it can be fixed. They do not modify the project's source code. They use the `postgres` superuser for local development only; production must use a dedicated database user.

The sections below are the manual steps for Linux/macOS or if you prefer to do it by hand.

## 0. Prerequisites

| Tool | Version | Check |
|---|---|---|
| PHP | 8.2 or newer, with extensions `pdo_pgsql`, `mbstring`, `intl`, `fileinfo`, `openssl`, `tokenizer`, `xml`, `ctype` | `php -v && php -m \| grep -E "pdo_pgsql\|mbstring\|intl\|fileinfo"` |
| Composer | 2.x | `composer --version` |
| Node.js | 20 or newer | `node -v` |
| PostgreSQL | 16 or newer, with contrib extensions `btree_gist` and `pg_trgm` | `psql --version` |

Ubuntu/Debian example: `sudo apt install php8.3-cli php8.3-pgsql php8.3-mbstring php8.3-intl php8.3-xml php8.3-curl php8.3-zip postgresql postgresql-contrib`

## 1. Database (from any folder)

```bash
sudo -u postgres psql <<'SQL'
CREATE USER el_shehab WITH PASSWORD 'choose-a-strong-password' CREATEDB;
CREATE DATABASE el_shehab      OWNER el_shehab;
CREATE DATABASE el_shehab_test OWNER el_shehab;
\c el_shehab
CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
\c el_shehab_test
CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
SQL
```

`el_shehab_test` is wiped by the automated tests. Never point it at real data.

## 2. Backend, in `backend/`

```bash
cd backend
composer install
cp .env.example .env
php artisan key:generate
```

Edit `backend/.env`. These values must be set for local development:

| Key | Local value | Why |
|---|---|---|
| `APP_ENV` / `APP_DEBUG` | `local` / `true` | never `true` in production |
| `APP_URL` | `http://127.0.0.1:8000` | |
| `FRONTEND_URL` | `http://localhost:3000` | links inside emails |
| `DB_USERNAME` / `DB_PASSWORD` / `DB_DATABASE` | `el_shehab` / your password / `el_shehab` | |
| `SESSION_SECURE_COOKIE` | `false` | local HTTP only; must be `true` behind HTTPS |
| `SANCTUM_STATEFUL_DOMAINS` | `localhost:3000` | **must equal the host:port of the Next.js site**, or login returns 401/419 |
| `SESSION_COOKIE` | `esn_session` | must equal `SESSION_COOKIE_NAME` in the frontend |
| `MAIL_MAILER` | `log` | password-reset emails are written to `storage/logs/laravel.log` instead of being sent |
| `DOCTOR_NAME`, `DOCTOR_EMAIL`, `DOCTOR_PASSWORD` | your choice, password 12+ characters | creates the doctor account; remove `DOCTOR_PASSWORD` after seeding |

Then:

```bash
php artisan migrate
php artisan db:seed
php artisan serve          # keep running: http://127.0.0.1:8000  (health check: /up)
```

## 3. Frontend, in `frontend/`

```bash
cd frontend
npm install
cp .env.example .env.local
```

`frontend/.env.local` for local development: `BACKEND_URL=http://127.0.0.1:8000`, `NEXT_PUBLIC_SITE_URL=http://localhost:3000`, `SESSION_COOKIE_NAME=esn_session`. Leave both logo variables empty until the official logo files are supplied.

```bash
npm run dev                # http://localhost:3000   Arabic at /, English at /en
```

Always open the site at **`http://localhost:3000`** (not `127.0.0.1:3000`). Sanctum matches the host exactly.

## 4. Checks you can run one at a time

| Where | Command | What it proves |
|---|---|---|
| repo root | `PGUSER=el_shehab PGPASSWORD=... PGHOST=localhost tests/db/run.sh` | database constraints (41 checks) |
| `backend/` | `DB_USERNAME=el_shehab DB_PASSWORD=... php artisan test` | 35 Laravel feature tests (auth, reset, sessions, roles, patient isolation) |
| `frontend/` | `npm run check:i18n` | Arabic and English files have the same keys |
| `frontend/` | `npm test` | route-access and validation unit tests (15) |
| `frontend/` | `npm run typecheck` | TypeScript, strict |
| `frontend/` | `npm run build` | Next.js 15 production build |
| `frontend/` | `npx playwright install chromium && npm run test:e2e` | browser tests (stack must be running; see below) |

Browser tests need the backend and a **production** frontend running, plus:

```bash
export E2E_DOCTOR_EMAIL=...   E2E_DOCTOR_PASSWORD=...        # the seeded doctor
export E2E_BACKEND_LOG="$(pwd)/../backend/storage/logs/laravel.log"
npm run build && npm run start      # in one terminal; php artisan serve in another
npm run test:e2e                    # in a third
```

## 5. Everything in one command

After sections 1 to 3 are configured, from the repository root:

```bash
export PGHOST=localhost PGUSER=el_shehab PGPASSWORD=...
export DB_USERNAME=el_shehab DB_PASSWORD=...
export E2E_DOCTOR_EMAIL=... E2E_DOCTOR_PASSWORD=...
scripts/verify-phase2.sh
```

It runs every check above in order, starts and stops both servers itself, and ends with a PASS / FAIL / SKIPPED summary. It exits non-zero if anything did not pass. Send me that summary.

## 6. Manual walk-through (what the browser tests also cover)

1. `/register`: create a patient. You land on `/patient/dashboard`, signed in.
2. Sign out. `/login` with a wrong password: you stay on `/login` with a message. Correct password: dashboard.
3. While signed in as the patient, open `/doctor/dashboard`: you are returned to the patient dashboard.
4. Sign in as the doctor: `/doctor/dashboard`. Open `/patient/dashboard`: you are returned to the doctor dashboard.
5. `/forgot-password`: submit any email. The same message appears for known and unknown emails. For a real account, open `backend/storage/logs/laravel.log`, copy the reset link, open it, set a new password, sign in. Using the same link again fails.
6. The language button switches between Arabic (RTL) and English (LTR) on the same page.
7. "Developed & Powered by CODING Systems" appears in the footer of every page.

## 7. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| Login or register answers **419** | The CSRF cookie did not reach the browser. Open the site at the same host as `SANCTUM_STATEFUL_DOMAINS` (`localhost:3000`). |
| Login succeeds but the next page sends you back to `/login` | `SESSION_COOKIE` (backend) and `SESSION_COOKIE_NAME` (frontend) differ, or `SESSION_SECURE_COOKIE=true` over plain HTTP. |
| `could not find driver` | Install `php-pgsql` and make sure `pdo_pgsql` appears in `php -m`. |
| `permission denied to create extension` | Run the `CREATE EXTENSION` lines in section 1 as a superuser. |
| Reset email never arrives | With `MAIL_MAILER=log` it is in `backend/storage/logs/laravel.log`. For real delivery set the `MAIL_*` values. |
| `DOCTOR_PASSWORD must be set ... at least 12 characters` | The seeder refuses weak or missing passwords on purpose. |
