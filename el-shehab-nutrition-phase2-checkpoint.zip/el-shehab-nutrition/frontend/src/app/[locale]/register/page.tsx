import { redirect } from 'next/navigation';
import { RegisterForm } from '@/components/forms/RegisterForm';
import { homeFor, withLocale, type Locale } from '@/lib/access';
import { getCurrentUser } from '@/lib/server-auth';

export default async function RegisterPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;

  const user = await getCurrentUser();
  if (user) redirect(withLocale(homeFor(user.role), locale));

  return <RegisterForm />;
}
