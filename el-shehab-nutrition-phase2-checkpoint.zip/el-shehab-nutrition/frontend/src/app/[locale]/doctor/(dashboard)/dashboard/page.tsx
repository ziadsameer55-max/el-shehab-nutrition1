import { type Locale } from '@/lib/access';
import { getMessages, translate } from '@/lib/i18n';
import { getCurrentUser } from '@/lib/server-auth';

export default async function DoctorDashboardPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  const m = getMessages(locale);
  const user = await getCurrentUser();

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{m.doctor.dashboardTitle}</h1>
      <p>{translate(m, 'doctor.greeting', { name: user?.name ?? '' })}</p>
      <p className="text-sm text-muted">{m.doctor.areaNote}</p>
    </div>
  );
}
