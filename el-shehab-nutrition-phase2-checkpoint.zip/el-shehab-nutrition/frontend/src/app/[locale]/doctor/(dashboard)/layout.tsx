import { redirect } from 'next/navigation';
import { type ReactNode } from 'react';
import { homeFor, withLocale, type Locale } from '@/lib/access';
import { getCurrentUser } from '@/lib/server-auth';

// Route group "(dashboard)" keeps the PUBLIC page /doctor (about the doctor, Phase 3) outside this guard,
// while everything under /doctor/dashboard, /doctor/patients, ... requires the doctor role.
export default async function DoctorDashboardLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ locale: Locale }>;
}) {
  const { locale } = await params;
  const user = await getCurrentUser();

  if (!user) redirect(withLocale('/login', locale));
  if (user.role !== 'doctor') redirect(withLocale(homeFor(user.role), locale));

  return <div className="mx-auto w-full max-w-6xl px-4 py-8">{children}</div>;
}
