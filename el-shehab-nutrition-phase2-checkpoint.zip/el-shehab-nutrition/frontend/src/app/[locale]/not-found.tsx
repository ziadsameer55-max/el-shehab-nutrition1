'use client';

import Link from 'next/link';
import { useLocale } from '@/components/LocaleProvider';

export default function NotFound() {
  const { t, href } = useLocale();
  return (
    <div className="mx-auto max-w-md px-4 py-16 text-center">
      <h1 className="text-2xl font-bold">{t('notFound.title')}</h1>
      <p className="mt-2 text-sm text-muted">{t('notFound.text')}</p>
      <Link href={href('/')} className="btn-primary mt-6">{t('notFound.home')}</Link>
    </div>
  );
}
