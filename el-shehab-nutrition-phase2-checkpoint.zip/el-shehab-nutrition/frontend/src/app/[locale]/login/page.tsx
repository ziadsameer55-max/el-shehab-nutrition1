import { redirect } from 'next/navigation';
import { LoginForm } from '@/components/forms/LoginForm';
import { homeFor, withLocale, type Locale } from '@/lib/access';
import { getMessages } from '@/lib/i18n';
import { getCurrentUser } from '@/lib/server-auth';

export default async function LoginPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: Locale }>;
  searchParams: Promise<{ next?: string; reset?: string }>;
}) {
  const [{ locale }, { next, reset }] = await Promise.all([params, searchParams]);

  const user = await getCurrentUser();
  if (user) redirect(withLocale(homeFor(user.role), locale));

  return <LoginForm next={next} notice={reset ? getMessages(locale).auth.resetDone : undefined} />;
}
