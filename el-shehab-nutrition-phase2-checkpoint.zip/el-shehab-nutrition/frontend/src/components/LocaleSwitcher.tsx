'use client';

import { usePathname, useSearchParams } from 'next/navigation';
import { splitLocale, withLocale } from '@/lib/access';
import { api } from '@/lib/api';
import { useLocale } from './LocaleProvider';

/** Switches AR/EN on the same page (keeping query string) and remembers the choice for signed-in users. */
export function LocaleSwitcher() {
  const { locale, t } = useLocale();
  const pathname = usePathname() || '/';
  const search = useSearchParams().toString();

  const target = locale === 'ar' ? 'en' : 'ar';
  const { path } = splitLocale(pathname);
  const destination = withLocale(path, target) + (search ? `?${search}` : '');

  function remember() {
    // Best effort: only succeeds for signed-in users; guests simply get 401, which we ignore.
    api('PATCH', '/auth/locale', { body: { locale: target }, locale: target }).catch(() => undefined);
  }

  return (
    <a href={destination} onClick={remember} hrefLang={target} lang={target} className="btn-secondary min-h-9 px-3">
      {t('nav.language')}
    </a>
  );
}
