'use client';

import Link from 'next/link';
import { useState, type FormEvent } from 'react';
import { api, type ApiUser } from '@/lib/api';
import { resolvePostLoginPath, withLocale } from '@/lib/access';
import { describeApiError } from '@/lib/form-errors';
import { isValidEmail } from '@/lib/validation';
import { Field } from '../Field';
import { useLocale } from '../LocaleProvider';
import { AuthCard, FormMessage } from './AuthCard';

export function LoginForm({ next, notice }: { next?: string; notice?: string }) {
  const { t, href, locale } = useLocale();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError('');

    const local: Record<string, string> = {};
    if (!isValidEmail(email)) local.email = t('errors.emailInvalid');
    if (!password) local.password = t('errors.passwordRequired');
    setErrors(local);
    if (Object.keys(local).length) return;

    setBusy(true);
    try {
      const user = await api<ApiUser>('POST', '/auth/login', { body: { email, password }, locale });
      // Full navigation so server layouts re-read the new session cookie.
      window.location.assign(withLocale(resolvePostLoginPath(next, user.role), locale));
    } catch (error) {
      const { fields, form } = describeApiError(error, t);
      setErrors(fields);
      setFormError(form);
      setBusy(false);
    }
  }

  return (
    <AuthCard title={t('auth.loginTitle')} subtitle={t('auth.loginSubtitle')}>
      <form onSubmit={onSubmit} noValidate className="space-y-4">
        {notice && <FormMessage kind="success">{notice}</FormMessage>}
        {formError && <FormMessage kind="error">{formError}</FormMessage>}
        <Field label={t('fields.email')} type="email" autoComplete="email" inputMode="email" dir="ltr"
          value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} />
        <Field label={t('fields.password')} type="password" autoComplete="current-password" dir="ltr"
          value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password} />
        <div className="text-end">
          <Link href={href('/forgot-password')} className="text-sm underline">
            {t('auth.forgotLink')}
          </Link>
        </div>
        <button type="submit" className="btn-primary w-full" disabled={busy}>
          {busy ? t('auth.loggingIn') : t('auth.loginButton')}
        </button>
        <p className="text-center text-sm text-muted">
          {t('auth.noAccount')}{' '}
          <Link href={href('/register')} className="font-semibold text-ink underline">
            {t('nav.register')}
          </Link>
        </p>
      </form>
    </AuthCard>
  );
}
