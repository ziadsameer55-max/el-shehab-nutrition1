'use client';

import { createContext, useContext, useMemo, type ReactNode } from 'react';
import { withLocale, type Locale } from '@/lib/access';
import { translate, type Messages } from '@/lib/i18n';

type Ctx = {
  locale: Locale;
  t: (key: string, vars?: Record<string, string>) => string;
  href: (path: string) => string;
};

const LocaleContext = createContext<Ctx | null>(null);

export function LocaleProvider({ locale, messages, children }: { locale: Locale; messages: Messages; children: ReactNode }) {
  const value = useMemo<Ctx>(
    () => ({
      locale,
      t: (key, vars) => translate(messages, key, vars),
      href: (path) => withLocale(path, locale),
    }),
    [locale, messages],
  );
  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale(): Ctx {
  const ctx = useContext(LocaleContext);
  if (!ctx) throw new Error('useLocale must be used inside <LocaleProvider>');
  return ctx;
}
