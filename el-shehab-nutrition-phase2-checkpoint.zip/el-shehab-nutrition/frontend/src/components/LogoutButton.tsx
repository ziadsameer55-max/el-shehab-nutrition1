'use client';

import { useState } from 'react';
import { api } from '@/lib/api';
import { useLocale } from './LocaleProvider';

export function LogoutButton() {
  const { t, href } = useLocale();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await api('POST', '/auth/logout');
    } catch {
      // Even if the call fails (e.g. the session already expired) we still leave the protected area.
    }
    // Full page load so every cached client state is dropped.
    window.location.assign(href('/login'));
  }

  return (
    <button type="button" onClick={logout} disabled={busy} className="btn-secondary min-h-9 px-3">
      {t('nav.logout')}
    </button>
  );
}
