// Browser-side API client. Same-origin calls to /api (proxied to Laravel by next.config.mjs).
// Auth is the HttpOnly Sanctum session cookie; the only thing readable here is the CSRF token.

export type ApiUser = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role: 'patient' | 'doctor';
  locale: 'ar' | 'en';
  health_profile_completed: boolean | null;
};

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public fieldErrors: Record<string, string[]> = {},
  ) {
    super(message);
  }
}

function xsrfToken(): string | null {
  const match = document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}

async function ensureCsrfCookie(): Promise<void> {
  if (xsrfToken()) return;
  await fetch('/sanctum/csrf-cookie', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
}

export async function api<T = unknown>(
  method: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE',
  path: string,
  options: { body?: unknown; locale?: 'ar' | 'en' } = {},
): Promise<T> {
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'Accept-Language': options.locale ?? document.documentElement.lang ?? 'ar',
  };

  if (method !== 'GET') {
    await ensureCsrfCookie();
    const token = xsrfToken();
    if (token) headers['X-XSRF-TOKEN'] = token;
  }
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';

  let response: Response;
  try {
    response = await fetch(`/api${path}`, {
      method,
      headers,
      credentials: 'same-origin',
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'network');
  }

  if (response.status === 204) return undefined as T;

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new ApiError(response.status, data?.message ?? 'error', data?.errors ?? {});
  }
  return data as T;
}
