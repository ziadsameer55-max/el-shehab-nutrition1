// Route-access rules shared by the middleware, the server layouts and the login redirect.
// Pure functions, no framework imports, so they are unit-tested in isolation (access.test.ts).
//
// IMPORTANT: this is user-experience routing only. The Laravel API re-checks identity, role and
// ownership on every request (spec section 7.2), so nothing here is a security boundary.

export const LOCALES = ['ar', 'en'] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = 'ar';

export type Role = 'patient' | 'doctor';
export type Area = 'public' | 'patient' | 'doctor';

/** Arabic (default) has no URL prefix; English lives under /en. */
export function splitLocale(pathname: string): { locale: Locale; path: string } {
  if (pathname === '/en' || pathname.startsWith('/en/')) {
    return { locale: 'en', path: pathname.slice(3) || '/' };
  }
  return { locale: DEFAULT_LOCALE, path: pathname || '/' };
}

export function withLocale(path: string, locale: Locale): string {
  if (locale === DEFAULT_LOCALE) return path;
  return path === '/' ? '/en' : `/en${path}`;
}

/**
 * Which area a (locale-less) path belongs to.
 * `/doctor` is the PUBLIC "about the doctor" page; everything under `/doctor/...` is the dashboard.
 */
export function areaOf(path: string): Area {
  const clean = path.length > 1 && path.endsWith('/') ? path.slice(0, -1) : path;
  if (clean === '/patient' || clean.startsWith('/patient/')) return 'patient';
  if (clean.startsWith('/doctor/')) return 'doctor';
  return 'public';
}

export function homeFor(role: Role): string {
  return role === 'doctor' ? '/doctor/dashboard' : '/patient/dashboard';
}

export function roleMayView(role: Role, area: Area): boolean {
  return area === 'public' || area === role;
}

/**
 * Middleware decision: protected areas need a session cookie. Returns the redirect target
 * (already locale-prefixed, with a `next` return path) or null to continue.
 * A stale cookie is handled later by the server layout, which asks the API who the user is.
 */
export function guardRedirect(opts: { path: string; locale: Locale; hasSession: boolean }): string | null {
  if (areaOf(opts.path) === 'public' || opts.hasSession) return null;
  return `${withLocale('/login', opts.locale)}?next=${encodeURIComponent(opts.path)}`;
}

/**
 * Validates a user-supplied return path. Only same-site, locale-less, absolute paths are allowed
 * (blocks open redirects such as //evil.com, https://evil.com and /\evil.com).
 */
export function safeNextPath(next: string | null | undefined, fallback: string): string {
  if (typeof next !== 'string' || next.length === 0 || next.length > 500) return fallback;
  if (!next.startsWith('/') || next.startsWith('//')) return fallback;
  if (next.includes('\\') || next.includes('://')) return fallback;
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u001f\u007f]/.test(next)) return fallback;
  return next;
}

/** Where to go after a successful login: the requested page if this role may see it, else the role's home. */
export function resolvePostLoginPath(next: string | null | undefined, role: Role): string {
  const home = homeFor(role);
  const candidate = safeNextPath(next, home);
  return roleMayView(role, areaOf(candidate)) ? candidate : home;
}
