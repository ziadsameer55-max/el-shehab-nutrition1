import 'server-only';
import { cookies } from 'next/headers';
import { type ApiUser } from './api';

const BACKEND_URL = (process.env.BACKEND_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');
const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/$/, '');

/**
 * Server-side "who is signed in?". Forwards the browser's cookies to Laravel.
 * Origin/Referer are set to the public site URL so Sanctum treats this call as the SPA.
 * Returns null when there is no valid session (the caller then redirects to login).
 */
export async function getCurrentUser(): Promise<ApiUser | null> {
  const cookieHeader = (await cookies()).toString();
  if (!cookieHeader) return null;

  try {
    const response = await fetch(`${BACKEND_URL}/api/auth/me`, {
      headers: { Cookie: cookieHeader, Accept: 'application/json', Referer: `${SITE_URL}/`, Origin: SITE_URL },
      cache: 'no-store',
    });
    if (!response.ok) return null;
    return (await response.json()) as ApiUser;
  } catch {
    return null;
  }
}
