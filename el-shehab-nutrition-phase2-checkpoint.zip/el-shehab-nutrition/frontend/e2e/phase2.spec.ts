import { expect, test, type Page } from '@playwright/test';
import { readFileSync } from 'node:fs';

// Phase 2 browser tests. They need the full stack running and these environment variables:
//   E2E_DOCTOR_EMAIL / E2E_DOCTOR_PASSWORD   the seeded doctor account
//   E2E_BACKEND_LOG                          path to backend/storage/logs/laravel.log (MAIL_MAILER=log)
// Cookie name must equal SESSION_COOKIE in backend/.env (default esn_session).

const SESSION_COOKIE = process.env.E2E_SESSION_COOKIE || 'esn_session';
const PASSWORD = 'Str0ngPassw0rd!';
const uniqueEmail = (tag: string) => `e2e.${tag}.${Date.now()}.${Math.floor(Math.random() * 1e6)}@example.com`;

async function register(page: Page, email: string, path = '/register') {
  await page.goto(path);
  await page.getByLabel(/الاسم الكامل|Full name/).fill('Test Patient');
  await page.getByLabel(/البريد الإلكتروني|^Email$/).fill(email);
  await page.getByLabel(/رقم الهاتف|Phone number/).fill('01001234567');
  await page.getByLabel(/^(كلمة المرور|Password)$/).fill(PASSWORD);
  await page.getByLabel(/تأكيد كلمة المرور|Confirm password/).fill(PASSWORD);
  await page.getByRole('checkbox').check();
  await page.locator('form button[type="submit"]').click();
}

async function login(page: Page, email: string, password: string, path = '/login') {
  await page.goto(path);
  await page.getByLabel(/البريد الإلكتروني|^Email$/).fill(email);
  await page.getByLabel(/^(كلمة المرور|Password)$/).fill(password);
  await page.locator('form button[type="submit"]').click();
}

async function logout(page: Page) {
  await page.getByRole('button', { name: /تسجيل الخروج|Sign out/ }).click();
  await page.waitForURL(/\/login/);
}

test.describe('CSRF and cookie flow through the Next.js proxy', () => {
  test('csrf-cookie is served through the proxy and state-changing calls need the token', async ({ page }) => {
    const csrf = await page.request.get('/sanctum/csrf-cookie');
    expect(csrf.status()).toBe(204);

    const cookies = await page.context().cookies();
    expect(cookies.find((c) => c.name === 'XSRF-TOKEN')).toBeTruthy();

    // No X-XSRF-TOKEN header: must be refused (419), not processed.
    const noToken = await page.request.post('/api/auth/login', {
      data: { email: 'x@example.com', password: 'whatever12345' },
      headers: { Accept: 'application/json', Origin: new URL(page.url() === 'about:blank' ? 'http://localhost:3000' : page.url()).origin },
    });
    expect(noToken.status()).toBe(419);
  });

  test('session cookie is HttpOnly and invisible to page scripts', async ({ page }) => {
    await register(page, uniqueEmail('cookie'));
    await page.waitForURL(/\/patient\/dashboard/);

    const session = (await page.context().cookies()).find((c) => c.name === SESSION_COOKIE);
    expect(session, 'session cookie present').toBeTruthy();
    expect(session!.httpOnly).toBe(true);
    expect(session!.sameSite).toBe('Lax');
    expect(await page.evaluate(() => document.cookie)).not.toContain(SESSION_COOKIE);
    expect(await page.evaluate(() => JSON.stringify({ ...localStorage }))).not.toMatch(/token/i);
  });
});

test.describe('Registration, login, logout, session', () => {
  test('register -> dashboard -> logout -> protected page redirects -> API says 401', async ({ page }) => {
    await register(page, uniqueEmail('flow'));
    await page.waitForURL(/\/patient\/dashboard/);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();

    await logout(page);
    await page.goto('/patient/dashboard');
    await expect(page).toHaveURL(/\/login\?next=%2Fpatient%2Fdashboard/);

    const me = await page.request.get('/api/auth/me', { headers: { Accept: 'application/json' } });
    expect(me.status()).toBe(401);
  });

  test('wrong password keeps the user on /login with a visible message', async ({ page }) => {
    const email = uniqueEmail('wrong');
    await register(page, email);
    await page.waitForURL(/\/patient\/dashboard/);
    await logout(page);

    await login(page, email, 'NotThePassword123');
    await expect(page).toHaveURL(/\/login/);
    await expect(page.getByRole('alert').first()).toBeVisible();
  });

  test('duplicate email is refused with a field error', async ({ page }) => {
    const email = uniqueEmail('dup');
    await register(page, email);
    await page.waitForURL(/\/patient\/dashboard/);
    await logout(page);

    await register(page, email);
    await expect(page).toHaveURL(/\/register/);
    await expect(page.getByRole('alert').first()).toBeVisible();
  });

  test('client-side validation blocks an empty registration without calling the API', async ({ page }) => {
    let apiCalls = 0;
    page.on('request', (r) => r.url().includes('/api/auth/register') && apiCalls++);
    await page.goto('/register');
    await page.locator('form button[type="submit"]').click();
    await expect(page.getByRole('alert').first()).toBeVisible();
    expect(apiCalls).toBe(0);
  });

  test('open-redirect attempt via ?next is ignored', async ({ page }) => {
    const email = uniqueEmail('redir');
    await register(page, email);
    await page.waitForURL(/\/patient\/dashboard/);
    await logout(page);

    await login(page, email, PASSWORD, '/login?next=//evil.example.com');
    await page.waitForURL(/\/patient\/dashboard/);
    expect(new URL(page.url()).hostname).toBe(new URL(process.env.E2E_BASE_URL || 'http://localhost:3000').hostname);
  });
});

test.describe('Roles', () => {
  test('a patient cannot enter the doctor dashboard', async ({ page }) => {
    await register(page, uniqueEmail('role'));
    await page.waitForURL(/\/patient\/dashboard/);
    await page.goto('/doctor/dashboard');
    await expect(page).toHaveURL(/\/patient\/dashboard/);
  });

  test('the doctor lands on the doctor dashboard and cannot enter the patient portal', async ({ page }) => {
    const email = process.env.E2E_DOCTOR_EMAIL;
    const password = process.env.E2E_DOCTOR_PASSWORD;
    test.skip(!email || !password, 'E2E_DOCTOR_EMAIL / E2E_DOCTOR_PASSWORD not set');

    await login(page, email!, password!);
    await page.waitForURL(/\/doctor\/dashboard/);
    await page.goto('/patient/dashboard');
    await expect(page).toHaveURL(/\/doctor\/dashboard/);
  });
});

test.describe('Password reset', () => {
  test('forgot -> email link -> new password -> login with it', async ({ page }) => {
    const logPath = process.env.E2E_BACKEND_LOG;
    test.skip(!logPath, 'E2E_BACKEND_LOG not set (needs MAIL_MAILER=log)');

    const email = uniqueEmail('reset');
    await register(page, email);
    await page.waitForURL(/\/patient\/dashboard/);
    await logout(page);

    await page.goto('/forgot-password');
    await page.getByLabel(/البريد الإلكتروني|^Email$/).fill(email);
    await page.locator('form button[type="submit"]').click();
    await expect(page.getByRole('status')).toBeVisible();

    // The mail is written to the Laravel log; take the LAST reset link for this email.
    await expect
      .poll(() => (readFileSync(logPath!, 'utf8').match(/reset-password\?token=[^\s"<>)]+/g) || []).length, { timeout: 15_000 })
      .toBeGreaterThan(0);
    const links = readFileSync(logPath!, 'utf8').match(/https?:\/\/[^\s"<>)]*reset-password\?token=[^\s"<>)]+/g)!;
    const link = links.filter((l: string) => l.includes(encodeURIComponent(email))).pop()!.replace(/&amp;/g, '&');
    expect(link).toBeTruthy();

    const url = new URL(link);
    await page.goto(`${url.pathname}${url.search}`);
    const newPassword = 'AnotherStr0ngPass1';
    await page.getByLabel(/^(كلمة المرور|Password)$/).fill(newPassword);
    await page.getByLabel(/تأكيد كلمة المرور|Confirm password/).fill(newPassword);
    await page.locator('form button[type="submit"]').click();
    await page.waitForURL(/\/login\?reset=1/);
    await expect(page.getByRole('status')).toBeVisible();

    await login(page, email, newPassword);
    await page.waitForURL(/\/patient\/dashboard/);

    // the same link must not work twice
    await logout(page);
    await page.goto(`${url.pathname}${url.search}`);
    await page.getByLabel(/^(كلمة المرور|Password)$/).fill('YetAnother1Pass99');
    await page.getByLabel(/تأكيد كلمة المرور|Confirm password/).fill('YetAnother1Pass99');
    await page.locator('form button[type="submit"]').click();
    await expect(page.getByRole('alert').first()).toBeVisible();
  });
});

test.describe('Arabic RTL, English LTR, branding', () => {
  test('document language and direction', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    await expect(page.locator('html')).toHaveAttribute('lang', 'ar');

    await page.goto('/en');
    await expect(page.locator('html')).toHaveAttribute('dir', 'ltr');
    await expect(page.locator('html')).toHaveAttribute('lang', 'en');
  });

  test('language switch keeps the page and the query string', async ({ page }) => {
    await page.goto('/login?next=%2Fpatient%2Fpayments');
    await page.getByRole('link', { name: 'English' }).click();
    await expect(page).toHaveURL(/\/en\/login\?next=%2Fpatient%2Fpayments/);
    await page.getByRole('link', { name: 'العربية' }).click();
    await expect(page).toHaveURL(/\/login\?next=%2Fpatient%2Fpayments/);
    expect(new URL(page.url()).pathname.startsWith('/en')).toBe(false);
  });

  test('internal /ar prefix is never public', async ({ page }) => {
    await page.goto('/ar/login');
    await expect(page).toHaveURL(/^[^?]*\/login$/);
    expect(new URL(page.url()).pathname).toBe('/login');
  });

  test('logical layout actually mirrors: the brand sits on the opposite side in RTL vs LTR', async ({ page }) => {
    const brandX = async () => (await page.locator('header a').first().boundingBox())!.x;
    const viewport = page.viewportSize()!.width;
    await page.goto('/');
    expect(await brandX()).toBeGreaterThan(viewport / 2); // right side in RTL
    await page.goto('/en');
    expect(await brandX()).toBeLessThan(viewport / 2); // left side in LTR
  });

  for (const path of ['/', '/login', '/register', '/forgot-password', '/en', '/en/login', '/en/register']) {
    test(`developer credit is visible on ${path}`, async ({ page }) => {
      await page.goto(path);
      await expect(page.locator('footer')).toContainText('CODING Systems');
    });
  }

  test('no brand logo or colour is invented: with no logo configured the brand is plain text', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('header img')).toHaveCount(0);
    await expect(page.locator('header')).toContainText('EL SHEHAB NUTRITION');
  });
});

test.describe('Responsive layout', () => {
  for (const path of ['/', '/login', '/register', '/forgot-password', '/en', '/en/register']) {
    test(`no horizontal scrolling on ${path}`, async ({ page }) => {
      await page.goto(path);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
      expect(overflow).toBeLessThanOrEqual(0);
    });
  }

  test('form controls are tap-sized on mobile', async ({ page }) => {
    await page.goto('/login');
    for (const el of await page.locator('form input:not([type=checkbox]), form button[type="submit"]').all()) {
      expect((await el.boundingBox())!.height).toBeGreaterThanOrEqual(40);
    }
  });
});
