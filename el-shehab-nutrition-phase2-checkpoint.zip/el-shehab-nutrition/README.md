# EL SHEHAB NUTRITION

Online nutrition consultation and follow-up platform.
**Developed & Powered by CODING Systems.**

Official requirements: *Project Specification & Developer Handover*. Architecture and delivery plan: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Status

| Phase | Status |
|---|---|
| 1. Architecture and database | **Done**: schema verified on PostgreSQL 16 (41 automated checks) |
| 2. Foundation (scaffolds, auth, roles, i18n shell) | **Code written, NOT verified.** See [`docs/VERIFICATION.md`](docs/VERIFICATION.md) for what ran and what did not |
| 3-9 | See architecture doc, section 11 |

On Windows, run `SETUP-WINDOWS.bat` once and then `START-WINDOWS.bat` (see `docs/SETUP.md`).

## Phase 1 contents

```
docs/ARCHITECTURE.md                      stack, state machines, security, phases, open client decisions
backend/database/sql/*.up.sql             the schema (30 tables, constraints, indexes, triggers)
backend/database/migrations/*.php        Laravel 12 migrations that run those SQL files
backend/database/seeders/                 settings defaults + doctor account (from .env, no default password)
backend/.env.example                      production-oriented environment template
tests/db/verify_schema.sql + run.sh       database-level acceptance tests
```

## Try the database now (needs PostgreSQL 16+ with `btree_gist` and `pg_trgm`)

```bash
# schema + constraint tests on a throwaway database
PGHOST=localhost PGUSER=postgres ./tests/db/run.sh
```

Once the Laravel project is scaffolded (Phase 2), the same schema is applied with `php artisan migrate` followed by `php artisan db:seed`. Set `DOCTOR_NAME`, `DOCTOR_EMAIL` and a 12+ character `DOCTOR_PASSWORD` in `.env` first; the seeder refuses to run without them.

## Design decisions worth knowing

- **Double booking is impossible at database level.** A PostgreSQL exclusion constraint rejects overlapping appointments for the same doctor, including buffer time, even under simultaneous requests.
- **Rejection requires a reason** and **approval requires a reviewer**, enforced by CHECK constraints, not just forms.
- **Success stories cannot be published without recorded consent**; photos need separate explicit consent.
- **The audit log cannot be edited or deleted**, even by the application (trigger-enforced).
- **No fake data is seeded.** The doctor enters services, packages, prices and hours from the dashboard.

## Phase 2 verification status

Phase 2 is **not verified**. Laravel and Next.js could not be installed where the code was written, so the 35 backend tests, the Next.js build and the browser tests have not been run. What did run (database tests, logic tests, type checks) and what did not is listed honestly in [`docs/VERIFICATION.md`](docs/VERIFICATION.md). Setup and the one-command check are in [`docs/SETUP.md`](docs/SETUP.md).
