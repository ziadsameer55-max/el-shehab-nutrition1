#!/usr/bin/env bash
# EL SHEHAB NUTRITION: Developed & Powered by CODING Systems
# Builds a throwaway PostgreSQL database from the migration SQL and runs the constraint tests.
# Usage: PGHOST=localhost PGUSER=postgres ./tests/db/run.sh   (needs CREATEDB rights)
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
DB="esn_schema_test_$$"

createdb "$DB"
trap 'dropdb --if-exists "$DB"' EXIT

for f in "$ROOT"/backend/database/sql/*.up.sql; do
  psql -v ON_ERROR_STOP=1 -q -1 -d "$DB" -f "$f" >/dev/null
done

psql -v ON_ERROR_STOP=1 -q -d "$DB" -f "$ROOT/tests/db/verify_schema.sql" 2>&1 | grep -E "PASS|FAIL|ERROR|ALL DATABASE"
