﻿# EL SHEHAB NUTRITION - start the site locally (Windows). Developed & Powered by CODING Systems.
$root = Split-Path -Parent $PSScriptRoot

if (-not (Test-Path "$root\backend\vendor\autoload.php") -or -not (Test-Path "$root\backend\.env") -or -not (Test-Path "$root\frontend\node_modules")) {
    Write-Host "The project is not set up yet. Run SETUP-WINDOWS.bat first." -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

Write-Host "Starting the backend (port 8000) and the website (port 3000) in two new windows..."
Write-Host "Close those two windows to stop the site."

$common = @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command')
Start-Process powershell -ArgumentList ($common + "Set-Location '$root\backend'; php artisan serve --host=127.0.0.1 --port=8000")
Start-Process powershell -ArgumentList ($common + "Set-Location '$root\frontend'; npm.cmd run dev")

Write-Host "Waiting for the site to start..."
Start-Sleep -Seconds 15
Start-Process 'http://localhost:3000'
Write-Host "Opened http://localhost:3000 in your browser. If it shows an error, wait 10 seconds and refresh."
Start-Sleep -Seconds 5
