﻿# EL SHEHAB NUTRITION - Windows setup (local development). Developed & Powered by CODING Systems.
# Double-click SETUP-WINDOWS.bat in the project folder. Safe to run again.
# It does NOT change any project source code. It only creates databases, .env files and installs packages.

$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot

function Step($msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }
function Fail($msg) {
    Write-Host ""
    Write-Host "STOP: $msg" -ForegroundColor Red
    Write-Host "Copy the text above (or take a screenshot) and send it to Claude." -ForegroundColor Yellow
    Read-Host "Press Enter to close"
    exit 1
}
function Have($cmd) { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function Exec($label, [scriptblock]$block) {
    & $block
    if ($LASTEXITCODE -ne 0) { Fail "$label failed (exit code $LASTEXITCODE)." }
}
function Set-Env($file, $key, $value) {
    $lines = New-Object 'System.Collections.Generic.List[string]'
    if (Test-Path $file) { foreach ($l in [System.IO.File]::ReadAllLines($file)) { $lines.Add($l) } }
    $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match ('^' + [regex]::Escape($key) + '=')) { $lines[$i] = "$key=$value"; $found = $true }
    }
    if (-not $found) { $lines.Add("$key=$value") }
    [System.IO.File]::WriteAllLines($file, $lines, (New-Object System.Text.UTF8Encoding($false)))
}
function Quote($v) { return '"' + $v.Replace('\', '\\').Replace('"', '\"').Replace('$', '\$') + '"' }

Write-Host "EL SHEHAB NUTRITION - local setup" -ForegroundColor Green

# ---------- 1. tools ----------
Step "Checking required programs"
$problems = @()
if (-not (Have 'php'))      { $problems += "PHP 8.2+ is not installed or not in PATH (https://windows.php.net/download)" }
if (-not (Have 'composer')) { $problems += "Composer is not installed (https://getcomposer.org/Composer-Setup.exe)" }
if (-not (Have 'node'))     { $problems += "Node.js 20+ is not installed (https://nodejs.org)" }

$psql = $null
if (Have 'psql') { $psql = (Get-Command psql).Source }
else {
    $psql = Get-ChildItem 'C:\Program Files\PostgreSQL' -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        ForEach-Object { Join-Path $_.FullName 'bin\psql.exe' } |
        Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $psql) { $problems += "PostgreSQL 16 is not installed (https://www.postgresql.org/download/windows/). Remember the password you choose for the 'postgres' user." }

if ($problems.Count -gt 0) {
    foreach ($p in $problems) { Write-Host " - $p" -ForegroundColor Red }
    Fail "Install the missing programs above, close this window, open a NEW one, and run SETUP-WINDOWS.bat again."
}

$phpVersion = (& php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
if ([version]$phpVersion -lt [version]'8.2') { Fail "PHP $phpVersion is too old. PHP 8.2 or newer is required." }
$nodeMajor = [int]((& node -v).TrimStart('v').Split('.')[0])
if ($nodeMajor -lt 20) { Fail "Node.js $nodeMajor is too old. Node 20 or newer is required." }
Write-Host "PHP $phpVersion, Node $nodeMajor, psql found. OK"

Step "Checking PHP extensions"
$mods = (& php -m) -join "`n"
$need = 'pdo_pgsql', 'pgsql', 'mbstring', 'intl', 'fileinfo', 'openssl', 'zip', 'curl'
$missing = @($need | Where-Object { $mods -notmatch ('(?im)^' + $_ + '$') })
if ($missing.Count -gt 0) {
    $ini = (& php --ini | Select-String 'Loaded Configuration File').ToString()
    Write-Host "Missing PHP extensions: $($missing -join ', ')" -ForegroundColor Red
    Write-Host $ini
    Write-Host "Open that php.ini file in Notepad, and for each missing name remove the ';' at the start of the line 'extension=NAME'." -ForegroundColor Yellow
    Fail "Fix php.ini, close this window, open a NEW one, and run SETUP-WINDOWS.bat again."
}
Write-Host "All required extensions are enabled. OK"

# ---------- 2. database ----------
Step "Database"
$sec = Read-Host "Enter the PostgreSQL password of user 'postgres' (chosen when you installed PostgreSQL)" -AsSecureString
$pgPass = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
$env:PGPASSWORD = $pgPass

$null = & $psql -h localhost -U postgres -w -tAc "SELECT 1"
if ($LASTEXITCODE -ne 0) { Fail "Could not connect to PostgreSQL on localhost:5432 with that password. Is the PostgreSQL service running, and is the password correct?" }

$exists = & $psql -h localhost -U postgres -w -tAc "SELECT 1 FROM pg_database WHERE datname='el_shehab'"
if ("$exists".Trim() -ne '1') {
    Exec "Creating database el_shehab" { & $psql -h localhost -U postgres -w -c "CREATE DATABASE el_shehab" }
}
Exec "Creating PostgreSQL extensions" {
    & $psql -h localhost -U postgres -w -d el_shehab -c "CREATE EXTENSION IF NOT EXISTS btree_gist" -c "CREATE EXTENSION IF NOT EXISTS pg_trgm"
}
Write-Host "Database el_shehab is ready. OK"

# ---------- 3. backend ----------
Step "Backend (Laravel): installing packages - this can take a few minutes"
Push-Location "$root\backend"
Exec "composer install" { & composer install --no-interaction --prefer-dist }

if (-not (Test-Path .env)) { Copy-Item .env.example .env }

$docEmail = Read-Host "Doctor login email (press Enter for doctor@example.com)"
if (-not $docEmail) { $docEmail = 'doctor@example.com' }
$alphabet = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
$docPass = -join (1..16 | ForEach-Object { $alphabet[(Get-Random -Maximum $alphabet.Length)] })

Set-Env .env 'APP_ENV' 'local'
Set-Env .env 'APP_DEBUG' 'true'
Set-Env .env 'APP_URL' 'http://127.0.0.1:8000'
Set-Env .env 'FRONTEND_URL' 'http://localhost:3000'
Set-Env .env 'DB_USERNAME' 'postgres'
Set-Env .env 'DB_PASSWORD' (Quote $pgPass)
Set-Env .env 'SESSION_SECURE_COOKIE' 'false'
Set-Env .env 'SANCTUM_STATEFUL_DOMAINS' 'localhost:3000'
Set-Env .env 'MAIL_MAILER' 'log'
Set-Env .env 'DOCTOR_NAME' 'Doctor'
Set-Env .env 'DOCTOR_EMAIL' $docEmail
Set-Env .env 'DOCTOR_PASSWORD' $docPass

if (Select-String -Path .env -Pattern '^APP_KEY=\s*$' -Quiet) {
    Exec "php artisan key:generate" { & php artisan key:generate --force }
}
Exec "php artisan migrate" { & php artisan migrate --force }
Exec "php artisan db:seed" { & php artisan db:seed --force }

# the one-time doctor password must not stay in the file after seeding
Set-Env .env 'DOCTOR_PASSWORD' ''
Pop-Location

# ---------- 4. frontend ----------
Step "Frontend (Next.js): installing packages - this can take a few minutes"
Push-Location "$root\frontend"
if (-not (Test-Path .env.local)) { Copy-Item .env.example .env.local }
Exec "npm install" { & npm.cmd install --no-audit --no-fund }
Pop-Location

# ---------- done ----------
Write-Host ""
Write-Host "=====================================================" -ForegroundColor Green
Write-Host " SETUP FINISHED" -ForegroundColor Green
Write-Host "=====================================================" -ForegroundColor Green
Write-Host " Doctor login email   : $docEmail"
Write-Host " Doctor login password: $docPass   (write it down now; it is not saved anywhere)"
Write-Host " (If the doctor account already existed, its old password is unchanged.)"
Write-Host ""
Write-Host " Next: double-click START-WINDOWS.bat, then open http://localhost:3000"
Write-Host " Always use 'localhost', not '127.0.0.1'."
Write-Host ""
Read-Host "Press Enter to close"
