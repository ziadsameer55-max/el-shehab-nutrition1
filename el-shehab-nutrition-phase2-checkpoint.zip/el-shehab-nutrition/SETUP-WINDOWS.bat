@echo off
title EL SHEHAB NUTRITION - Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\setup.ps1"
